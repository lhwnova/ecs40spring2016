// 1
// Author: Sean Davis
#ifndef timeH
#define timeH

class Time
{
  short hour;
  short minute;
public:
  void read();
  void print()const;
}; // class Time
#endif
